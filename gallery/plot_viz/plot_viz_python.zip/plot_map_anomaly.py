# -*- coding: utf-8 -*-
r"""
绘制中国地图上的气温距平场（1963 年 1 月）
==========================================

本章目标
--------
用 ``stipple.nc`` 数据绘制 1963 年 1 月的温度距平等值线图，并在中国地图上：
正距平（1 月比气候态偏暖）格点用 ``+`` 号标出、负距平（偏冷）格点用 ``-`` 号标出。

它综合了四件事：用 xarray 读取 NetCDF、用 Matplotlib 画等值线（contourf）、
用 Cartopy 叠加中国国界（shapefile）、按格点符号标注距平正负。

所需数据（点击按钮下载，与本脚本放在同一目录）
------------------------------------------------

.. container:: sphx-glr-download meteopy-download-nc

   :download:`下载格点温度数据 stipple.nc </data/stipple.nc>`

.. container:: sphx-glr-download meteopy-download-nc

   :download:`下载中国国界 shapefile（4 个文件） </data/china.dbf>`

中国国界 shapefile 实际为 ``china.shp``、``china.shx``、``china.prj``、``china.dbf``
四个配套文件，需一并下载放在同一目录。

数据说明
--------
``stipple.nc`` 是一份全球 73×96 的教学格点场：

* longitude：0°~356.25°，步长 3.75°；latitude：90°N~90°S，步长 2.5°；
* jan1963：1963 年 1 月的气温场（℃）；
* climatology：多年 1 月平均气候态气温场（℃）。

距平（anomaly）＝ jan1963 − climatology，即某时次相对常年同期的偏差：
正距平表示当月较常年偏暖，负距平表示偏冷。距平量级与 ℃ 相同、但口径不同，
气象上常说"××年 1 月偏暖 0.5 ℃"，指的就是距平。
"""

# %%
# ---------- ① 导入库 + 中文字体配置 ----------
import os

import numpy as np
import matplotlib.pyplot as plt
import xarray as xr
from cartopy import crs as ccrs
from cartopy import feature as cft
from cartopy.io import shapereader

# 中文字体：Windows 常见微软雅黑 / 黑体；Linux 常见文泉驿；macOS 常见苹方。
# 每个系统换对应字体即可。axes.unicode_minus=False 解决坐标轴负号显示为方块的问题。
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "WenQuanYi Micro Hei"]
plt.rcParams["axes.unicode_minus"] = False

# %%
# ---------- ② 读取数据：优先项目配套 NetCDF，缺失时退回合成场 ----------
# 脚本可能在文档构建目录、或读者本地目录运行，逐个尝试常见相对路径。
NC_CANDIDATES = ["./data/stipple.nc",
                 "../data/stipple.nc",
                 "../../data/stipple.nc",
                 "../../../data/stipple.nc"]
nc_path = next((p for p in NC_CANDIDATES if os.path.exists(p)), None)

if nc_path:
    ds = xr.open_dataset(nc_path)
    jan1963 = ds["jan1963"].values      # (lat, lon)
    clim    = ds["climatology"].values  # (lat, lon)
    lon     = ds["longitude"].values    # 0°~356.25°
    lat     = ds["latitude"].values     # 90°N~90°S（北→南）
    source  = f"配套数据 {nc_path}"
else:
    # 兜底：数据缺失时生成结构一致的合成场，保证脚本任何环境都能运行
    lon  = np.arange(0.0, 357.0, 3.75)
    lat  = np.arange(90.0, -90.5, -2.5)
    LON, LAT = np.meshgrid(lon, lat)
    rng = np.random.default_rng(1963)
    jan1963 = 10 + 0.05 * (LAT + 90) + rng.normal(0, 4.0, size=LON.shape)
    clim    = 10 + 0.05 * (LAT + 90)
    source  = "合成场（未找到数据文件）"

print("数据来源：", source)
print("jan1963 形状 (纬度数, 经度数):", jan1963.shape)

# %%
# ---------- ③ 计算距平并转换为更通用的经度 -180°~180° ----------
# 原数据经度为 0°~356.25°，把它归一到 -180°~180°，与常见的 -180~180 习惯一致，
# 绘图时 set_extent 才能用常规的 [东/西经度] 写法。
anomaly = jan1963 - clim                       # 距平：正值偏暖、负值偏冷
lon_180 = ((lon + 180.0) % 360.0) - 180.0      # 如 73°E 仍为 +73°，356°→-4°

print("距平范围 (℃):", f"{anomaly.min():.2f} ~ {anomaly.max():.2f}")

# %%
# ---------- ④ 判别正、负距平格点（该区域中心在中国附近，便于观察）----------
# 仅在中国区域（约 73~138°E, 15~56°N）标注，避免全球密布太多符号。
lon_msk = (lon_180 >= 73) & (lon_180 <= 138)
lat_msk = (lat >= 15) & (lat <= 56)

# 用布尔数组定位满足条件的 (i_lat, i_lon) 下标
pos_i, pos_j = np.where(lat_msk[:, None] & lon_msk[None, :] & (anomaly > 0))
neg_i, neg_j = np.where(lat_msk[:, None] & lon_msk[None, :] & (anomaly < 0))

print(f"正距平格点数：{len(pos_i)}，负距平格点数：{len(neg_i)}")

# %%
# ---------- ⑤ 读取中国国界 shapefile（Cartopy Feature）----------
SHP_CANDIDATES = ["./china.shp", "../china.shp", "../../china.shp",
                  "../../data/china.shp", "../../../data/china.shp"]
shp_path = next((p for p in SHP_CANDIDATES if os.path.exists(p)), None)

if shp_path:
    # shapereader.Reader 读 .shp 的几何（多面），转为 ShapelyFeature 供 add_feature 叠加
    china_geom = shapereader.Reader(shp_path).geometries()
    china_feature = cft.ShapelyFeature(
        china_geom, crs=ccrs.PlateCarree(),
        edgecolor="black", facecolor="none")
    has_border = True
else:
    # 无国界文件时的兜底：用 Cartopy 自带的 50m 国家边界代替
    china_feature = cft.NaturalEarthFeature(
        "cultural", "admin_0_boundary_lines_land", "50m",
        edgecolor="black", facecolor="none")
    has_border = False
print("国界来源：", "china.shp" if has_border else "Cartopy 内置 50m 国界")

# %%
# ---------- ⑥ 绘图：主图 = 中国区域距平场 + 正负标注 ----------
# 投影统一用 PlateCarree（等经纬度），因为网格数据就是等经纬度格点。
fig = plt.figure(figsize=(9, 7), layout="constrained")

ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())

# 填充等值线：显示距平场分布，coolwarm 蓝冷红暖，与"正偏暖/负偏冷"直觉一致
cf = ax.contourf(lon_180, lat, anomaly, cmap="coolwarm",
                 levels=20, transform=ccrs.PlateCarree(), extend="both")

# 叠加海岸线/陆地/海洋底图，增强地理可读性（50m 为中等分辨率）
ax.coastlines(resolution="50m", linewidth=0.4, edgecolor="gray")
ax.add_feature(cft.LAND.with_scale("50m"), alpha=0.05, zorder=0)
ax.add_feature(cft.OCEAN.with_scale("50m"), alpha=0.05, zorder=0)

# 叠加中国国界
ax.add_feature(china_feature, linewidth=0.8, zorder=3)

# 在地图上标注正负距平格点：'+' 偏暖、'-' 偏冷
ax.scatter(lon_180[pos_j], lat[pos_i], c="k", marker="+", s=14,
           transform=ccrs.PlateCarree(), label="正距平（偏暖）", zorder=4)
ax.scatter(lon_180[neg_j], lat[neg_i], c="k", marker="_", s=14,
           transform=ccrs.PlateCarree(), label="负距平（偏冷）", zorder=4)
ax.legend(loc="lower right")

# 限定显示范围：中国及其邻域（左下角中国，右下图见 step7 南海小图）
ax.set_extent([73, 138, 15, 56], crs=ccrs.PlateCarree())

# 经纬网格 + 刻度标签：投影图中承担横、纵轴标注的是经纬网格线标签
gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True, dms=True,
                  x_inline=False, y_inline=False, color="gray",
                  linestyle="--", alpha=0.6, linewidth=0.5)
gl.top_labels = False
gl.right_labels = False

ax.set_title("1963 年 1 月气温距平场及正负距平分布", fontsize=13)

cbar = fig.colorbar(cf, ax=ax, orientation="vertical", pad=0.03, aspect=40)
cbar.set_label("气温距平（℃）")
cbar.ax.tick_params(labelsize=9)

plt.show()

# %%
# ---------- ⑦ 补充：南海诸岛小图（中国地图惯例）----------
# 我国地图绘制通常在主图右下角补一张南海放大图。这里沿用同一投影与渲染方式。
ax_so = fig.add_axes((0.70, 0.10, 0.26, 0.22), projection=ccrs.PlateCarree())
ax_so.contourf(lon_180, lat, anomaly, cmap="coolwarm", levels=20,
               transform=ccrs.PlateCarree(), extend="both")
ax_so.add_feature(china_feature if has_border
                  else cft.NaturalEarthFeature("cultural",
                                               "admin_0_boundary_lines_land",
                                               "50m", edgecolor="black",
                                               facecolor="none"),
                  linewidth=0.6, zorder=3)
ax_so.annotate("南海诸岛", xy=(114, 17), xytext=(118, 22),
               arrowprops=dict(arrowstyle="->", color="gray"),
               fontsize=9, color="gray")
ax_so.set_extent([105, 125, 0, 25], crs=ccrs.PlateCarree())
ax_so.set_title("南海诸岛", fontsize=9)

print("绘图完成：主图为中国区域距平场，右下角为南海诸岛小图。")